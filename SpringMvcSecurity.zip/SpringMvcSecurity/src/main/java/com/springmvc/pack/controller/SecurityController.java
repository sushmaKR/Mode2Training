package com.springmvc.pack.controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class SecurityController {
	private static final Logger logger = LoggerFactory.getLogger(SecurityController.class);
	@RequestMapping(value = "/init", method = RequestMethod.GET)
	public String welcome(Model model) {
		logger.info("Returning welcome.jsp page");
		return "welcome";
	}
	
	
	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	public String admin(Model model) {
		logger.info("Returning admin.jsp page");
		return "admin";
	}
	
	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public String user(Model model) {
		logger.info("Returning user.jsp page");
		return "user";
	}
}
