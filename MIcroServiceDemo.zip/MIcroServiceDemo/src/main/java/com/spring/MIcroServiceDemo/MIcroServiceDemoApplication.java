package com.spring.MIcroServiceDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MIcroServiceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MIcroServiceDemoApplication.class, args);
	}

}
