package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.AccountDao;
import com.example.demo.dao.CustomerDao;
import com.example.demo.dto.CustomerDto;
import com.example.demo.model.Account;
import com.example.demo.model.Customer;

@Service
public class CustomerService {

	@Autowired
	private CustomerDao customerDao;

	@Autowired
	private AccountDao accountdao;

	int accno1 = 20000;
	int pass = 23455;
	int custidno = 200;
	ModelMapper model = new ModelMapper();
	List<CustomerDto> list = new ArrayList<>();
	Account acc = new Account();

	// adding customer Details into a table

	public String addCustomerDetails(Customer customer) {

		if (customer.getCust_age() < 21)
			return "age should be equal or greater than 21";
		customer.setCust_id(custidno++);
		customer.setCust_passwd(pass++);
		customerDao.save(customer);

		acc.setAccno("SBI" + accno1++);
		acc.setAmount(2000000);
		accountdao.save(acc);
		return "successuflly added";
	}

	// List of Customer details
	public List<CustomerDto> getAll() {
		customerDao.findAll().forEach(customer -> convertToDTO(customer));
		return list;
	}

	private void convertToDTO(Customer customer) {
		list.add(model.map(customer, CustomerDto.class));

	}

	// get Customer Details by customer Id
	public Optional<Customer> getcustomer(Integer custid) {
		return customerDao.findById(custid);
	}

	// Delete Customer Details By customer Id
	public void deleteCustomer(Integer custid1) {
		customerDao.deleteById(custid1);
	}

	// Update Customer Details
	
	public String updatecustomer(Customer customer, Integer custid2) {
		Customer c = customerDao.findById(custid2).orElse(customer);
		if (null != customer) {
			c.setCust_job(customer.getCust_job());
			c.setCust_email(customer.getCust_email());
			c.setCust_phone_no(customer.getCust_phone_no());
		}
		customerDao.save(c);
		return "Success";
	}

}
