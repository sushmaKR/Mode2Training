package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.CustomerDto;
import com.example.demo.model.Customer;
import com.example.demo.service.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	CustomerService customerService;

	@RequestMapping(value = "/customer/add", method = RequestMethod.POST)
	public String addCustomerDetails(@RequestBody Customer customer) {
		customerService.addCustomerDetails(customer);
		return "Successfully Added";
	}

	@RequestMapping(value = "/customer/get", method = RequestMethod.GET)
	@ResponseBody
	public List<CustomerDto> getAll() {
		return customerService.getAll();
	}

	@RequestMapping(value = "/customer/getcustomer/{cust_id}", method = RequestMethod.GET)
	@ResponseBody
	public Optional<Customer> getcustomer(@PathVariable(value = "cust_id") Integer custid) {
		return customerService.getcustomer(custid);
	}

	@DeleteMapping(value = "/customer/delete/{cust_id}")
	public void deleteCustomer(@PathVariable(value = "cust_id") Integer custid1) {
		customerService.deleteCustomer(custid1);
	}

	@PutMapping(value = "/customer/update/{cust_id}")
	public void updatecustomer(@PathVariable(value = "cust_id") Integer custid2, @RequestBody Customer update) {
		customerService.updatecustomer(update, custid2);
	}

}
