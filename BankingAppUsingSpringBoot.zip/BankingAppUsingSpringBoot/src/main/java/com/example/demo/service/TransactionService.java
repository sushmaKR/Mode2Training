package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.dao.AccountDao;
import com.example.demo.dao.TransactionDao;
import com.example.demo.dao.TransactionRepository;
import com.example.demo.dto.TransactionDto;
import com.example.demo.exception.AccountNotFoundException;
import com.example.demo.exception.InsufficientBalanceException;
import com.example.demo.model.Account;
import com.example.demo.model.Transaction;

@Service
public class TransactionService {

	 Logger logger = LoggerFactory.getLogger(TransactionService.class);
	@Autowired
	TransactionRepository repository;

	int fromBalance;
	int toBalance;
	ModelMapper model = new ModelMapper();
	List<TransactionDto> list = new ArrayList<>();
	int id = 10;

	@Autowired
	AccountDao accountdao;

	@Autowired
	TransactionDao transactiondao;

	Account a = new Account();

	// List of all transactions
	public List<TransactionDto> getAll() {
		transactiondao.findAll().forEach(transaction -> convertToDTO(transaction));

		return list;
	}

	private void convertToDTO(Transaction transaction) {
		list.add(model.map(transaction, TransactionDto.class));

	}

	// get Customer account Details from his account number
	public Transaction getDetails(String accnum) {
		Transaction trans = transactiondao.findById(accnum).orElse(null);
		if (trans == null) {
			throw new AccountNotFoundException("AccountNotFound" + accnum);
		}
		return trans;
	}

	// Adding transactions into a database
	public String transactionadd(TransactionDto transDto) {
		Transaction trans = new Transaction();
		Transaction trans1 = new Transaction();

		list.add(model.map(a, TransactionDto.class));

		Account acclist1 = accountdao.findById(transDto.getAccfrom()).orElse(null);
		Account acclist2 = accountdao.findById(transDto.getAccto()).orElse(acclist1);

		if (acclist1 == null) {
			throw new AccountNotFoundException("Account not found" + "--" + transDto.getAccfrom());
		}

		trans.setAccno(transDto.getAccfrom());
		trans.setCustamount(transDto.getCustamount());
		trans.setDescription("sent to " + transDto.getAccto());
		trans.setTransactionType("Debit");
		transactiondao.save(trans);
		if (transDto.getCustamount() < acclist1.getAmount()) {
			logger.info("You have sufficient balance to make transaction!!");

			fromBalance = acclist1.getAmount();
			toBalance = acclist2.getAmount();
			fromBalance = fromBalance - transDto.getCustamount();
			toBalance = toBalance + transDto.getCustamount();
			acclist1.setAmount(fromBalance);
			acclist2.setAmount(toBalance);
			accountdao.save(acclist1);
			accountdao.save(acclist2);

			trans1.setAccno(transDto.getAccto());
			trans1.setCustamount(transDto.getCustamount());
			trans1.setDescription("Received from " + transDto.getAccfrom());
			trans1.setTransactionType("Credit");
			transactiondao.save(trans1);
			return "Transaction Over";
		}
		throw new InsufficientBalanceException("InsufficientBalanceException" + "--" + transDto.getCustamount());

	}

	//Adding Atm Transaction into a table
	public String addAtmTransaction(TransactionDto transDto) {
		Transaction trans = new Transaction();
		Account a = new Account();
		list.add(model.map(a, TransactionDto.class));
		Account acclist1 = accountdao.findById(transDto.getAccfrom()).orElse(null);
		if (acclist1 == null) {
			throw new AccountNotFoundException("Account not found" + "--" + transDto.getAccfrom());
		}

		trans.setAccno(transDto.getAccfrom());
		trans.setCustamount(transDto.getCustamount());
		trans.setTransactionType("Debit");
		transactiondao.save(trans);
		if (transDto.getCustamount() < acclist1.getAmount()) {
			logger.info("You have sufficient balance to make transaction!!");
			fromBalance = acclist1.getAmount();
			fromBalance = fromBalance - transDto.getCustamount();
			acclist1.setAmount(fromBalance);
			accountdao.save(acclist1);
			return "Transaction Over";
		}
		throw new InsufficientBalanceException("InsufficientBalanceException" + "--" + transDto.getCustamount());
	}

	//Paging of all transaction
	public List<Transaction> getAllTransaction(Integer pageNo, Integer pageSize, String sortBy) {
		Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));

		Page<Transaction> pagedResult = repository.findAll(paging);

		if (pagedResult.hasContent()) {
			return pagedResult.getContent();
		} else {
			return new ArrayList<>();
		}
	}

}
