package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.TransactionDto;
import com.example.demo.model.Transaction;
import com.example.demo.service.TransactionService;

@RestController
public class TransactionController {

	@Autowired
	TransactionService transactionService;

	@GetMapping(value = "/customer/gettransactions")
	@ResponseBody
	public List<TransactionDto> getAll() {
		return transactionService.getAll();
	}

	@RequestMapping(value = "/customer/transaction/add")
	public String transactionadd(@RequestBody TransactionDto transDto) {

		return transactionService.transactionadd(transDto);
	}

	@RequestMapping(value = "/customer/transaction/atm")
	public String transactionadd1(@RequestBody TransactionDto transDto) {

		return transactionService.addAtmTransaction(transDto);
	}

	@GetMapping(value = "/customer/transaction/list")
	public ResponseEntity<List<Transaction>> getAllTransaction(@RequestParam(defaultValue = "0") Integer pageNo,
			@RequestParam(defaultValue = "10") Integer pageSize,
			@RequestParam(defaultValue = "custamount") String sortBy) {
		List<Transaction> list = transactionService.getAllTransaction(pageNo, pageSize, sortBy);

		return new ResponseEntity<>(list, new HttpHeaders(), HttpStatus.OK);
	}
}
