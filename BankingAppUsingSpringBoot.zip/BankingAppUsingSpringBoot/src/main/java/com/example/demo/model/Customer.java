package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "customer11")
public class Customer {
	@Column(name = "cust_name")
	private String cust_name;

	@Column(name = "cust_age")
	private int cust_age;

	@Column(name = "cust_phone_no")
	private int cust_phone_no;

	@Column(name = "cust_email")
	private String cust_email;

	@Column(name = "cust_job")
	private String cust_job;

	@Column(name = "cust_passwd")
	private int cust_passwd;
	@Id
	@Column(name = "cust_id")

	private int cust_id;

	public String getCust_name() {
		return cust_name;
	}

	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}

	public int getCust_age() {
		return cust_age;
	}

	public void setCust_age(int cust_age) {
		this.cust_age = cust_age;
	}

	public int getCust_phone_no() {
		return cust_phone_no;
	}

	public void setCust_phone_no(int cust_phone_no) {
		this.cust_phone_no = cust_phone_no;
	}

	public String getCust_email() {
		return cust_email;
	}

	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}

	public String getCust_job() {
		return cust_job;
	}

	public void setCust_job(String cust_job) {
		this.cust_job = cust_job;
	}

	
	public int getCust_passwd() {
		return cust_passwd;
	}

	public void setCust_passwd(int cust_passwd) {
		this.cust_passwd = cust_passwd;
	}

	public int getCust_id() {
		return cust_id;
	}

	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}

}
