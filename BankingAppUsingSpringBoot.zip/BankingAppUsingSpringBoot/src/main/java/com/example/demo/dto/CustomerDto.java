package com.example.demo.dto;

public class CustomerDto {
	private String cust_name;
	private String cust_email;
	private int cust_age;
	private int cust_phone_no;
	private String cust_job;

	public String getCust_name() {
		return cust_name;
	}

	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}

	public String getCust_email() {
		return cust_email;
	}

	public void setCust_email(String cust_email) {
		this.cust_email = cust_email;
	}

	public int getCust_age() {
		return cust_age;
	}

	public void setCust_age(int cust_age) {
		this.cust_age = cust_age;
	}

	public int getCust_phone_no() {
		return cust_phone_no;
	}

	public void setCust_phone_no(int cust_phone_no) {
		this.cust_phone_no = cust_phone_no;
	}

	public String getCust_job() {
		return cust_job;
	}

	public void setCust_job(String cust_job) {
		this.cust_job = cust_job;
	}

}
