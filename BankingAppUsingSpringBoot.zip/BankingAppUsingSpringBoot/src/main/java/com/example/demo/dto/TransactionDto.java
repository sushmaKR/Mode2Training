package com.example.demo.dto;

public class TransactionDto {
	private String accfrom;
	private String accto;
	private int custamount;

	public String getAccfrom() {
		return accfrom;
	}

	public void setAccfrom(String accfrom) {
		this.accfrom = accfrom;
	}

	public String getAccto() {
		return accto;
	}

	public void setAccto(String accto) {
		this.accto = accto;
	}

	public int getCustamount() {
		return custamount;
	}

	public void setCustamount(int custamount) {
		this.custamount = custamount;
	}

}
