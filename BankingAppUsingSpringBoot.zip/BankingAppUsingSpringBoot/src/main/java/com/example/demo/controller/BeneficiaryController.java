package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Beneficiary;

import com.example.demo.service.BeneficiaryService;

@RestController
public class BeneficiaryController {

	@Autowired
	BeneficiaryService beneficiaryService;

	@GetMapping(value = "/customer/getifsc/{ifsc}")
	@ResponseBody
	public List<Beneficiary> findByifsc(@PathVariable(value = "ifsc") String ifsc) {
		return beneficiaryService.findByifsc(ifsc);
	}

	@GetMapping(value = "/customer/getcustomer/{ifsc}/{bacc}")
	@ResponseBody
	public List<Beneficiary> findByifscAndBacc(@PathVariable(value = "ifsc") String ifsc,
			@PathVariable(value = "bacc") String bacc) {
		return beneficiaryService.findByifscAndBacc(ifsc, bacc);
	}

}
