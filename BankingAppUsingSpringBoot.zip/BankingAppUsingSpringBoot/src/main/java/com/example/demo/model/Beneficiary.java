package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Beneficiary3")
public class Beneficiary {
	@Id
	@Column(name = "custid")
	private String custid;
	@Column(name = "bacc")
	private String bacc;
	@Column(name = "ifsc")
	private String ifsc;

	public String getCustid() {
		return custid;
	}

	public void setCustid(String custid) {
		this.custid = custid;
	}

	public String getBacc() {
		return bacc;
	}

	public void setBacc(String bacc) {
		this.bacc = bacc;
	}

	public String getIfsc() {
		return ifsc;
	}

	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}

}
