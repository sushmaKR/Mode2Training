package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.BeneficiaryDao;
import com.example.demo.model.Beneficiary;


@Service
public class BeneficiaryService {

	@Autowired
	BeneficiaryDao bendao;

	ModelMapper model = new ModelMapper();
	List<Beneficiary> list = new ArrayList<>();

	//Get List by finding ifsc code
	public List<Beneficiary> findByifsc(String ifsc) {
		return bendao.findByifsc(ifsc);
	}

	//Get List by finding both ifsc and beneficiary account
	public List<Beneficiary> findByifscAndBacc(String ifsc, String bacc) {
		return bendao.findByifscAndBacc(ifsc, bacc);
	}

}
