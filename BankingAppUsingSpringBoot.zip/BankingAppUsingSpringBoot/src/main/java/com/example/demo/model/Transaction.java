package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "transaction8")
public class Transaction {
	@Id
	@Column(name="trans_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int trans_id;
	
	
	@Column(name="accno")
	private String accno;
	
	@Column(name = "custamount")
	private int custamount;

	@Column(name = "transactionType")
	private String transactionType;

	@Column(name = "description")
	private String description;

	
	

	public int getTrans_id() {
		return trans_id;
	}

	public void setTrans_id(int trans_id) {
		this.trans_id = trans_id;
	}

	public String getAccno() {
		return accno;
	}

	public void setAccno(String accno) {
		this.accno = accno;
	}

	

	public int getCustamount() {
		return custamount;
	}

	public void setCustamount(int custamount) {
		this.custamount = custamount;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
