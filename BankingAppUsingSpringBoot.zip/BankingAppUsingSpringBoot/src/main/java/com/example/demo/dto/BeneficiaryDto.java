package com.example.demo.dto;

public class BeneficiaryDto {
	private int cust_id;

	public int getCust_id() {
		return cust_id;
	}

	public void setCust_id(int cust_id) {
		this.cust_id = cust_id;
	}

}
