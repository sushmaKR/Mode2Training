package com.example.demo.testservice;

import java.util.Optional;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.example.demo.dao.CustomerDao;
import com.example.demo.model.Customer;
import com.example.demo.service.CustomerService;


@RunWith(MockitoJUnitRunner.Silent.class)
public class CustomerSeviceTest {

	@Mock
	CustomerDao customerDao;
	
	@InjectMocks
	CustomerService customerService;
	
	@Test
	public void testGetcustomer() {
		Customer customer=new Customer();
		customer.setCust_name("sushma");
		customer.setCust_id(1); 
		customer.setCust_age(22);
		Optional<Customer> customers = Optional.of(customer);
			
		Mockito.when(customerDao.findById(1)).thenReturn(customers);
	
		Optional<Customer> result= customerService.getcustomer(1);
		Assert.assertNotNull(result);
	}
	
	
	
	
}
