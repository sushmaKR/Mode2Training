package com.hcl.pp;


public class TestBeanConfig {

}
