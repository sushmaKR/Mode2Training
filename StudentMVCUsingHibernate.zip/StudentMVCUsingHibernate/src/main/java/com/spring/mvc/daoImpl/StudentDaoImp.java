package com.spring.mvc.daoImpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import java.util.Random;

import javax.swing.tree.RowMapper;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.mvc.dao.StudentDao;
import com.spring.mvc.exception.USNNotFoundException;
import com.spring.mvc.model.Academics;
import com.spring.mvc.model.College;
import com.spring.mvc.model.Student;

@Component
public class StudentDaoImp implements StudentDao {

	@Autowired
	Academics academics;

	@Autowired
	SessionFactory sessionFactory;

	@Transactional
	@Override
	public void StudentRegistration(Student student, Academics academics) {
		sessionFactory.getCurrentSession().save(student);

		sessionFactory.getCurrentSession().save(academics);

	}

	@Override
	@Transactional
	public List<Student> getProduct(int result, int offsetreal) {
		Criteria criteria = sessionFactory.getCurrentSession().createCriteria(Student.class);
		criteria.setFirstResult(offsetreal);
		criteria.setMaxResults(result);
		List<Student> products = (List<Student>) criteria.list();
		return products;
	}

	@Override
	@Transactional
	public void save(Student product) {
		sessionFactory.getCurrentSession().save(product);
	}

	@Override
	@Transactional
	public int getSize() {
		return sessionFactory.getCurrentSession().createCriteria(Student.class).list().size();
	}

	@Transactional
	@Override
	public String StudentPlace(Student student) {

		String usnCollegeCode;
		String getstring;
		String place = null;
		getstring = student.getUsn();
		if (student.getUsn() == null)
			throw new USNNotFoundException("USN not found" + "--" + student.getUsn());
		StringBuffer s = new StringBuffer(getstring);
		String substring = s.substring(1, 3);

		System.out.println(substring);
		Session session = sessionFactory.openSession();

		String sql_query = "from College where collegecode = '" + substring + "'";
		System.out.println("After query.....");
		Query query = session.createQuery(sql_query);

		List list = query.list();

		System.out.println("Display the content of list");
		Iterator i = list.iterator();
		while (i.hasNext()) {
			Object obj = (Object) i.next();
			College studlist = (College) obj;
			System.out.println(studlist.getPlace());
			place = studlist.getPlace();

		}
		session.close();
		return "The student Place is" + " "+place;
	}

	public static List<Student> getStudentsByPage(int pageid, int total) {
		// TODO Auto-generated method stub

		Object obj = null;
		Configuration cfg = new Configuration();
		cfg.configure();
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		String sql = "from Student";
		Query query = session.createQuery(sql);
		query.setFirstResult(pageid - 1);
		query.setMaxResults(total);
		List<Student> stddet = new ArrayList<Student>();
		List studlist = query.list();
		System.out.println("Displaying pagination contents");
		Iterator it = studlist.iterator();
		Student std = new Student();
		while (it.hasNext()) {
			std = (Student) it.next();
			System.out.println(
					std.getUsn() + "  " + std.getStudentname() + "  " + std.getFather() + " " + std.getMother());
			stddet.add(std);
		}
		return stddet;
	}
	
	//list in postman
		@Override
		@Transactional
		public List<Student> getStudentsByPage(){
			Criteria criteria = sessionFactory.getCurrentSession().createCriteria(Student.class);
			List<Student> student = (List<Student>) criteria.list();
			return student;
		}

		@Override
		@Transactional
		public List<Student> getAge(){
			Criteria criteria = sessionFactory.getCurrentSession().createCriteria(Student.class);
			criteria.add(Restrictions.gt("age", 18));
			List list = criteria.list();
			
			//List<Student> student = (List<Student>) criteria.list();
			return list;
		}

		@Override
		@Transactional
		public List<Student> getPer(){
			Criteria criteria = sessionFactory.getCurrentSession().createCriteria(Student.class);
			criteria.add(Restrictions.gt("percentage", 30));
			List list = criteria.list();
			
			//List<Student> student = (List<Student>) criteria.list();
			return list;
		}
		
		
}
