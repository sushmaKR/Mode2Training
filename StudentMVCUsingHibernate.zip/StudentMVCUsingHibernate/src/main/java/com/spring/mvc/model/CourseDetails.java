package com.spring.mvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@IdClass(CourseDetailskey.class)
@Table(name="CourseDetails1")
public class CourseDetails {
	
	@Id
	 @Column(name = "collegecode")
	private String collegecode;
	
	@Id
	 @Column(name = "course")
	private String course;

}
