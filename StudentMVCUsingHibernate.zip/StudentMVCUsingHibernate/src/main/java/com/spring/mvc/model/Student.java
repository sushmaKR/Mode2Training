package com.spring.mvc.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student1")
public class Student {
	@Id
	 @Column(name = "usn")
	private String usn;
	
	 @Column(name = "studentname")
	private String studentname;
	 
	 @Column(name = "age")
	private int age;
	 
	 @Column(name = "phone")
	private long phone;
	 
	 @Column(name = "email")
	private String email;
	 
	 @Column(name = "father")
		private String father;

	 @Column(name = "mother")
		private String mother;
	 
	 @Column(name = "percentage")
		private int percentage;
	 




	public String getUsn() {
		return usn;
	}

	public void setUsn(String usn) {
		this.usn = usn;
	}

	public String getStudentname() {
		return studentname;
	}

	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public long getPhone() {
		return phone;
	}

	public void setPhone(long phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFather() {
		return father;
	}

	public void setFather(String father) {
		this.father = father;
	}

	public String getMother() {
		return mother;
	}

	public void setMother(String mother) {
		this.mother = mother;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}
	 

	
	
}
