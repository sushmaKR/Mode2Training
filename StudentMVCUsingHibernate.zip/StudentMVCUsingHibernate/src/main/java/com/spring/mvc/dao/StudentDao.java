package com.spring.mvc.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.spring.mvc.model.Academics;
import com.spring.mvc.model.Student;

@Component
public interface StudentDao {

	
	
	public String StudentPlace(Student student);
	public void StudentRegistration(Student student, Academics academic);
	public List<Student> getStudentsByPage();
	public List<Student> getAge();
	public List<Student> getPer();
	
	
        
	List<Student> getProduct(int result, int offsetreal) ;;
	void save(Student product) ;
	int getSize();

	

	
}
