package com.spring.mvc.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.ResponseBody;



import com.spring.mvc.dao.StudentDao;
import com.spring.mvc.daoImpl.StudentDaoImp;
import com.spring.mvc.dto.StudentDto;
import com.spring.mvc.exception.USNNotFoundException;
import com.spring.mvc.model.Academics;
import com.spring.mvc.model.Student;

@Controller
public class StudentController {
	
private  StudentDao studentdao;



	@Autowired(required=true)
	@Qualifier(value="studentdao")
	public void setPersonService(StudentDao s){
		this.studentdao = s;
	}

	private static final Logger logger = LoggerFactory.getLogger(StudentController.class);

	private Map<String, Student> stud = null;

	public StudentController() {
		stud = new HashMap<String, Student>();
	}
	
	//adding student registration
	@RequestMapping(value = "/stud/add", method = RequestMethod.GET)
	public String getAll(@ModelAttribute("studentDto")StudentDto studentDto,BindingResult bindingResult, Model model) {
		logger.info("Returning studentreg.jsp page");
		model.addAttribute("studentDto", new StudentDto());//model.addAttribute("listPersons", this.studentdao.listUser());
		return "studentreg";
	}

	@RequestMapping(value= "/stud/add.do", method = RequestMethod.POST)
	public String addPerson(@ModelAttribute("studentDto") StudentDto studentDto ,BindingResult bindingResult, Model model){
		
		    
		if (bindingResult.hasErrors()) {
			logger.info("Returning userregn.jsp page");
			return "studentreg";
		}
		logger.info("Returning registered.jsp page");
		ModelMapper mapper = new ModelMapper();
		Student student = mapper.map(studentDto, Student.class);
		Academics academic = mapper.map(studentDto, Academics.class);
		model.addAttribute("studentDto", studentDto);
		model.addAttribute("stud", stud);
		studentdao.StudentRegistration(student,academic);
		return "registered";
		
	}
	
	
	
	//Searching student place
	@RequestMapping(value= "/stud/search", method = RequestMethod.GET)
	public String searchStudent(@ModelAttribute("student") Student student,BindingResult bindingResult, Model model)
	{
		logger.info("Returning searchstudent.jsp page");
		model.addAttribute("student", new Student());
		return "SearchForm";
	}
	
	
	@RequestMapping(value= "/stud/search.do", method = RequestMethod.POST)
	@ResponseBody
	public String StudentPlace(@ModelAttribute("student") Student student,BindingResult bindingResult, Model model)
	{
		logger.info("Returning searchstudent page");
		if(student.getUsn()==null) 
			throw new USNNotFoundException("USN not found" + "--" + student.getUsn());

		model.addAttribute("student", student);
		return studentdao.StudentPlace(student);
		
	}
	
	//listing the student details using pagination
	@RequestMapping(value= "/stud/students", method = RequestMethod.GET)
	public String getStudentDetails(@ModelAttribute("studentDto") StudentDto studentDto ,BindingResult bindingResult, Model model)
	{
		logger.info("Returning index1.jsp page");
		return "index1";	
	}
	
	
	@RequestMapping(value="viewemp/{pageid}") 
	public String StudentDetails(@PathVariable int pageid,Model model)
	{
		int total=10;    
        if(pageid==1){}    
        else{    
            pageid=(pageid-1)*total+1;    
        }    
        System.out.println(pageid);  
        List<Student> list=StudentDaoImp.getStudentsByPage(pageid,total);    
          model.addAttribute("msg", list);  
        return "studentlist";    
	}
	
	
	//Searching in postman
		@RequestMapping(value = "/search")
		@ResponseBody
		public String jdata(@RequestBody Student student) {
			return studentdao.StudentPlace(student);
		}

		//listing in postman
		@RequestMapping(value = "/list")
		@ResponseBody
		public List<Student> getStudentsByPage() {
			return studentdao.getStudentsByPage();
		}
		
		@RequestMapping(value = "/getage")
		@ResponseBody
		public List<Student> Age() {
			return studentdao.getAge();
		}
		
		@RequestMapping(value = "/getper")
		@ResponseBody
		public List<Student> getPer(){
			return studentdao.getPer();
		}
		
		
		
	}
	
	
	
	
	
	
	
