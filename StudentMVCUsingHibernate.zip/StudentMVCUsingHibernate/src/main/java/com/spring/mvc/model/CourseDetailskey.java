package com.spring.mvc.model;

import java.io.Serializable;

public class CourseDetailskey implements Serializable {

	String collegecode;

	String course;

}
