package com.spring.MovieBooking.DaoImp;

import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.MovieBooking.dao.ShowDao;
import com.spring.MovieBooking.dao.TheaterDao;
import com.spring.MovieBooking.model.Show;
import com.spring.MovieBooking.model.Theater;

@Service
public class ShowDaoImpl {

	@Autowired
	private ShowDao showDao;
	int id=1;
	public String addShowDetails(Show show) {
		show.setTheaterid(id++);
		showDao.save(show);
		return "Successfully added";
	}
		
      }

