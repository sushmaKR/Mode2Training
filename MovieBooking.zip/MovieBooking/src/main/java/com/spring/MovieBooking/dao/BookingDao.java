package com.spring.MovieBooking.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.spring.MovieBooking.model.Booking;


@Repository
public interface BookingDao extends CrudRepository<Booking, Integer>{
	public Booking addbooking(String moviename,int theaterid,String show);
	
}
