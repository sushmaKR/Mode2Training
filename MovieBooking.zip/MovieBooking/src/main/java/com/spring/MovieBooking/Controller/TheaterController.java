package com.spring.MovieBooking.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.MovieBooking.DaoImp.TheaterDaoImpl;
import com.spring.MovieBooking.Dto.TheaterDto;
import com.spring.MovieBooking.model.Theater;

@RestController
public class TheaterController {
	@Autowired
	TheaterDaoImpl theaterdaoImpl;

	@RequestMapping(value = "/add/theater", method = RequestMethod.POST)
	public String addCustomerDetails(@RequestBody Theater theater) {
		theaterdaoImpl.addTheaterDetails(theater);
		return "Successfully Added";
	}

	@RequestMapping(value = "/add/movie/{moviename}", method = RequestMethod.GET)
	public List<TheaterDto> getcustomer(@PathVariable(value = "moviename") String movie) {
		return theaterdaoImpl.findByMoviename(movie);
	}
}
