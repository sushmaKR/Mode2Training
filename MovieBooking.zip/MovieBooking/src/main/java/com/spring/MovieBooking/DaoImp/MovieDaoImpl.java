package com.spring.MovieBooking.DaoImp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.spring.MovieBooking.dao.MovieDao;


import com.spring.MovieBooking.model.MovieModel;



@Service
public class MovieDaoImpl {
	@Autowired
	private MovieDao movieDao;
	
	public String addMovieDetails(MovieModel movie) {
		movieDao.save(movie);
		return "Successfully added";
	}
	
	
}
