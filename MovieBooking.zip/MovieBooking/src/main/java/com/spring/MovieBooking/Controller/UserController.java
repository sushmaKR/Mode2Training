package com.spring.MovieBooking.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.spring.MovieBooking.DaoImp.UserDaoImpl;
import com.spring.MovieBooking.model.User;

@RestController
public class UserController {
	@Autowired
	UserDaoImpl userdaoImpl;

	@RequestMapping(value = "/add/user", method = RequestMethod.POST)
	public String addCustomerDetails(@RequestBody User user) {
		userdaoImpl.addUserDetails(user);
		return "Successfully Added";
	}
}
