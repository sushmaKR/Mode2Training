package com.spring.MovieBooking.DaoImp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.MovieBooking.dao.UserDao;

import com.spring.MovieBooking.model.User;

@Service
public class UserDaoImpl {
	int userid=10;
	@Autowired
	private UserDao userDao;
	
	public String addUserDetails(User user) {
		user.setUserid(userid++);
		userDao.save(user);
		return "Successfully added";
	}
}
