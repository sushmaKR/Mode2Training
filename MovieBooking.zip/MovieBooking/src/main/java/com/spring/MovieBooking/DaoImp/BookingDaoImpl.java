package com.spring.MovieBooking.DaoImp;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.MovieBooking.model.MovieModel;
import com.spring.MovieBooking.model.Show;
import com.spring.MovieBooking.model.Theater;
import com.spring.MovieBooking.dao.BookingDao;
import com.spring.MovieBooking.dao.ShowDao;
import com.spring.MovieBooking.dao.TheaterDao;
import com.spring.MovieBooking.model.Booking;

@Service
public class BookingDaoImpl {
	
	@Autowired
	BookingDao bookingdao;

	@Autowired
	TheaterDao theaterdao;
	
	@Autowired
	ShowDao showdao;
	
	
	
	public Booking addbooking(String moviename,int theaterid,String show) {
		int user_id=10;
		int bookingid=1;
		Booking book=new Booking();
		Theater theater=theaterdao.findById(theaterid).orElse(null);
		Show shows=showdao.findById(theaterid).orElse(null);
		
		book.setMoviename(moviename);
		book.setShowtime(show);
		book.setTheatername(theater.getTheatername());
		book.setDate(LocalDate.now());
		book.setUserid(user_id++);
		book.setBookingid(bookingid++);
		return bookingdao.save(book);
	}

}
