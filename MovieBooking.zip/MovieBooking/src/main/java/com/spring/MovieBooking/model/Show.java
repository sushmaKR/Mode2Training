package com.spring.MovieBooking.model;

import java.time.LocalDate;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "show1")
public class Show {

	@Column(name = "date")
	private LocalDate date;
	
	@Id
	@Column(name = "theaterid")
	private int theaterid;
	
	@Column(name = "morning")
	private String morning;
	
	@Column(name = "afternoon")
	private String afternoon;
	
	@Column(name = "evening")
	private String evening;



	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public int getTheaterid() {
		return theaterid;
	}

	public void setTheaterid(int theaterid) {
		this.theaterid = theaterid;
	}

	public String getMorning() {
		return morning;
	}

	public void setMorning(String morning) {
		this.morning = morning;
	}

	public String getAfternoon() {
		return afternoon;
	}

	public void setAfternoon(String afternoon) {
		this.afternoon = afternoon;
	}

	public String getEvening() {
		return evening;
	}

	public void setEvening(String evening) {
		this.evening = evening;
	}
}
