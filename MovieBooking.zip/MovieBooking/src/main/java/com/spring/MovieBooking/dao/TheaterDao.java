package com.spring.MovieBooking.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import org.springframework.stereotype.Repository;

import com.spring.MovieBooking.Dto.TheaterDto;
import com.spring.MovieBooking.model.Theater;

@Repository
public interface TheaterDao extends CrudRepository<Theater, Integer> {
	@Query(value="select * from Theater1 t where t.theaterid in (select s.theaterid from Show1 s where s.morning=?1 or s.afternoon=?1 or s.evening=?1)", nativeQuery=true)
	
	List<Theater> findByMoviename(String movie);

	
	


}
