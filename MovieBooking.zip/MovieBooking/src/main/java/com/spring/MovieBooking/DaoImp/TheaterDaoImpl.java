package com.spring.MovieBooking.DaoImp;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import com.spring.MovieBooking.Dto.TheaterDto;
import com.spring.MovieBooking.dao.ShowDao;
import com.spring.MovieBooking.dao.TheaterDao;
import com.spring.MovieBooking.model.Show;
import com.spring.MovieBooking.model.Theater;

@Service
public class TheaterDaoImpl {
	int id = 1;
	@Autowired
	private TheaterDao theaterDao;

	@Autowired
	private ShowDao showDao;

	public String addTheaterDetails(Theater theater) {
		theater.setTheaterid(id++);
		theaterDao.save(theater);
		return "Successfully added";
	}

	public List<TheaterDto> findByMoviename(String movie) {
		List<Theater> theater = theaterDao.findByMoviename(movie);
		List<Show> show = showDao.findshow(movie);
		Theater t = new Theater();
		List<TheaterDto> list = new ArrayList<>();
		
		for (Show listshow : show) {
			TheaterDto dto = new TheaterDto();
			int theater_id = listshow.getTheaterid();
			t = theaterDao.findById(theater_id).orElse(null);

			dto.setTheatername(t.getTheatername());
			dto.setPlace(t.getPlace());
			dto.setMorning(listshow.getMorning());
			dto.setAfternoon(listshow.getAfternoon());
			dto.setEvening(listshow.getEvening());
			list.add(dto);
		}
		return list;
	}

}
