package com.spring.MovieBooking.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.spring.MovieBooking.DaoImp.ShowDaoImpl;

import com.spring.MovieBooking.model.Show;

@RestController
public class ShowController {
	@Autowired
	ShowDaoImpl showdaoImpl;

	@RequestMapping(value = "/add/show", method = RequestMethod.POST)
	public String addCustomerDetails(@RequestBody Show show) {

		showdaoImpl.addShowDetails(show);
		return "Successfully Added";
	}
}
