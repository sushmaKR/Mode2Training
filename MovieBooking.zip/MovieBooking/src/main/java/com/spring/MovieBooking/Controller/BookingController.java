package com.spring.MovieBooking.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.MovieBooking.DaoImp.BookingDaoImpl;

import com.spring.MovieBooking.model.Booking;

@RestController
public class BookingController {

	@Autowired
	BookingDaoImpl bookingdaoimpl;

	@RequestMapping(value = "/add/movie/{moviename}/{theaterid}/{show}", method = RequestMethod.POST)
	@ResponseBody
	public Booking addbooking(@PathVariable(value = "moviename") String moviename,
			@PathVariable(value = "theaterid") int theaterid, @PathVariable(value = "show") String show) {
		return bookingdaoimpl.addbooking(moviename, theaterid, show);
	}
}
