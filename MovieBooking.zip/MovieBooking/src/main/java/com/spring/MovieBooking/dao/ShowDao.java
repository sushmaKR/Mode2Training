package com.spring.MovieBooking.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.spring.MovieBooking.model.Show;
@Repository
public interface ShowDao extends CrudRepository<Show, Integer>{

	@Query(value="select * from Show1 s where s.morning=?1 or s.afternoon=?1 or s.evening=?1 ",nativeQuery=true)
	List<Show> findshow(String moviename);
}
