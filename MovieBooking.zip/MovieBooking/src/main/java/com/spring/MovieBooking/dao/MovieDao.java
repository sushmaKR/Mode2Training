package com.spring.MovieBooking.dao;




import org.springframework.data.repository.CrudRepository;

import org.springframework.stereotype.Repository;


import com.spring.MovieBooking.model.MovieModel;
@Repository
public interface MovieDao extends CrudRepository<MovieModel, String> {
	
	
	

}
