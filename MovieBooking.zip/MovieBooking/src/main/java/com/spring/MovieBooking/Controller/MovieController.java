package com.spring.MovieBooking.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.spring.MovieBooking.DaoImp.MovieDaoImpl;
import com.spring.MovieBooking.DaoImp.TheaterDaoImpl;

import com.spring.MovieBooking.model.MovieModel;
import com.spring.MovieBooking.model.Theater;

@RestController
public class MovieController {
	@Autowired
	MovieDaoImpl moviedaoImpl;

	@RequestMapping(value = "/add/movie", method = RequestMethod.POST)
	public String addMovieDetails(@RequestBody MovieModel movie) {
		moviedaoImpl.addMovieDetails(movie);
		return "Successfully Added";
	}

}
